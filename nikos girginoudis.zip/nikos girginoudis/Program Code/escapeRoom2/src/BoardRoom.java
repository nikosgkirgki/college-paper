import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class BoardRoom {
    //This is a list of all the tiles our board has.
    private ArrayList<Tile> tilesArray = new ArrayList<Tile>();
    //These are the upper limits of the y and x axis.
    private static int xAxis;
    private static int yAxis;
    //The constructor is private because no other class will have
    //the need to use it.
    private BoardRoom(ArrayList<Tile> tilesArray) {
        this.tilesArray = tilesArray;
    }
    //This method reads the text file with all the boardroom data
    //and creates a BoardRoom Object.
    public static BoardRoom createBoardRoom(String filePath) throws FileNotFoundException {
        //EXTRACTING THE DATA FROM THE TEXT FILE STARTS HERE!
        //This here scanner reads the file.
        Scanner fileReader = new Scanner(new File(filePath));
        //This here Arraylist will house the text
        //from the textFile.
        ArrayList<String> ListOfStrings = new ArrayList<String>();
        //With this here loop, we insert every text line
        //into our Arraylist as a different entry.
        while (fileReader.hasNext()) {
            ListOfStrings.add(fileReader.nextLine());
        }
        //Here we create the attributes of the
        //BoardRoom object we are making...
        xAxis = 0;
        yAxis = 0;
        ArrayList<Tile> tilesArray = new ArrayList<Tile>();
        //...and here we create a few lists, in which
        //we are going to put the data we extracted
        //from the text document and is in the "ListOfStrings"
        //arraylist.
        String[] walls;
        List<String> holes = new ArrayList<String>();
        List<String> exit = new ArrayList<String>();
        //Now we are going to loop the ListOfStrings
        //and extract the data we need and put it
        // in the above String arrays.
        for(int i = 0; i < ListOfStrings.size(); i++){
            String line = ListOfStrings.get(i);
            if(line.equals("number of rows")){
                xAxis = Integer.parseInt(ListOfStrings.get(i + 1));
            }else if(line.equals("number of columns")){
                yAxis = Integer.parseInt(ListOfStrings.get(i + 1));
            }else if(line.equals("human start")){
                List<String> extractHumanStart = Arrays.asList(ListOfStrings.get(i + 1).split(","));
                ArrayList<String> humanStartArrayList = new ArrayList<String>();
                String humanString = extractHumanStart.get(0);
                humanStartArrayList.add(humanString);
                humanString = extractHumanStart.get(1);
                humanStartArrayList.add(humanString);
                Human.setHumanStartCoordinates(humanStartArrayList);
            }else if(line.equals("monster start")){
                List<String> extractMonsterStart = Arrays.asList(ListOfStrings.get(i + 1).split(","));
                ArrayList<String> monsterStartArrayList = new ArrayList<String>();
                String monsterString = extractMonsterStart.get(0);
                monsterStartArrayList.add(monsterString);
                monsterString = extractMonsterStart.get(1);
                monsterStartArrayList.add(monsterString);
                Monster.setMonsterStartCoordinates(monsterStartArrayList);
            }else if(line.equals("holes")){
                holes = Arrays.asList(ListOfStrings.get(i + 1).split(","));
            }else if(line.equals("exit")){
                exit = Arrays.asList(ListOfStrings.get(i + 1).split(","));
            }else if(line.equals("walls")){
                //Since we don't know how many lines the walls' numbers occupy, we will
                //command the program to use ALL the lines from this point on, since we
                //know that there is NOTHING in the text file AFTER the walls' numbers,
                //so we are safe.
                for(int j = i + 1; j < ListOfStrings.size(); j++){
                    walls = ListOfStrings.get(i + 1).split(",");
                    //We are going to give the array to the Move class so that it can generate
                    //the walls. We need to do it here, since we just initialized walls[]
                    //inside the if clause.
                    Terrain.generateWalls(walls);
                }
            }
        }
        //Here we set up the coordinates for the exit tile.
        int exitX = Integer.parseInt(exit.get(0));
        int exitY = Integer.parseInt(exit.get(1));
        //Notice that we do not deal with the holes List yet.
        //We are now going to start creating our board.
        //CREATING THE BOARD STARTS HERE!
        //First we create the tiles using the xAxis and y
        //lengths and a double for loop.
        for(int i = 1; i <= xAxis; i++){
            for(int j = 1;j <= yAxis; j++){
                Tile tile = new Tile( i, j, "normal");
                tilesArray.add(tile);
            }
        }
        //Our board now has its tiles, but they are
        //all devoid of any data. bellow we are going to
        //give every tile its characteristics as dictated by
        //the data we got from the text file.
        //We begin with the exit tile.
        for(int i = 0; i < tilesArray.size(); i++){
            //if the tile's x equals the exit's x...
            if(tilesArray.get(i).getX() == exitX){
                //...and if the tile's y equals the exit's y...
                if(tilesArray.get(i).getY() == exitY){
                    //...then we change the tile's type to "exit".
                    tilesArray.get(i).setTileType("exit");
                }
            }
        }
        //Now we need to change the appropriate tiles into
        //hole tiles. For this, we are using a for loop
        //inside another for loop, yet again.
        //First we loop the holes arraylist. Notice how the i variable
        //is increased by 2 each time.
        //Before that though, we create an array to house
        //all the hole tiles.
        ArrayList<Tile> holeTiles = new ArrayList<Tile>();
        for(int i = 0;i < holes.size(); i+=2){
            //In this loop, we now need to loop the tilesArray list.
            for(int j = 0; j < tilesArray.size(); j++){
                //Inside this second loop, we are going to
                //do what we did in the exit loop.
                if(Integer.parseInt(holes.get(i)) == tilesArray.get(j).getX()){
                    if(Integer.parseInt(holes.get(i+1)) == tilesArray.get(j).getY()){
                        tilesArray.get(j).setTileType("hole");
                        //Here is where each hole tile is
                        //injected into the array.
                        holeTiles.add(tilesArray.get(j));
                    }
                }
            }
        }
        //Lastly, we give the arraylist to the Move
        //class, since it is there that the
        //appropriate checks are made.
        Terrain.setHoles(holeTiles);
        //Now that our tiles are complete, all we need to do is
        //create our board using the constructor and return it.
        //Now, let's set up the upper limit of moves per attempt.
        return new BoardRoom(tilesArray);
    }
//BEGINNING OF GETTERS AND SETTERS!!!
    public ArrayList<Tile> getTilesArray() {
        return tilesArray;
    }
    public void setTilesArray(ArrayList<Tile> tilesArray) {
        this.tilesArray = tilesArray;
    }

    public static int getXAxis() {
        return xAxis;
    }

    public static int getYAxis() {
        return yAxis;
    }
    //ENDING OF GETTERS AND SETTERS!!!
}
