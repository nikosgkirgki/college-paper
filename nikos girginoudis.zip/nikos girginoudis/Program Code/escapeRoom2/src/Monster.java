import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class Monster {
    private int monsterX;
    private int monsterY;
    //To keep in mind if the monster is in a hole and can't move.
    private int monsterIsInHole;
    private static List<String> monsterStartCoordinates = new ArrayList<String>();
    //This arraylist keeps all the moves the human and then the monster makes in ONE escape attempt.
    //The content of this list will be printed for us to see the escape attempt's history, and
    //NOT for the a.i. to use. (We have a different arraylist for that).
    private static ArrayList<String> monsterAndHumanMovesLog = new ArrayList<String>();
    public Monster(){
        //Even though we don't give human its variables in the
        //arguments, it still gets them from the arrayList.
        this.monsterX = Integer.parseInt(monsterStartCoordinates.get(0));
        this.monsterY = Integer.parseInt(monsterStartCoordinates.get(1));
        this.monsterIsInHole = 0;
    }
    private boolean monsterFellInHole(){
        boolean fallCheck = false;
        for(int i = 0; i < Terrain.getHoles().size(); i++){
            if(this.monsterX == Terrain.getHoles().get(i).getX() && this.monsterY == Terrain.getHoles().get(i).getY()){
                    fallCheck = true;
            }
        }
        return fallCheck;
    }
    //Now to create a method that checks if the human is eaten by the monster.
    private boolean humanIsEaten(int humanX, int humanY){
        boolean isEaten = false;
        if(this.monsterX == humanX && this.monsterY == humanY){
            isEaten = true;
        }
        return isEaten;
    }
//!!!BEGINNING OF SETTERS AND GETTERS!!!
    public void setMonsterX(int monsterX) {
        this.monsterX = monsterX;
    }

    public void setMonsterY(int monsterY) {
        this.monsterY = monsterY;
    }

    public static void setMonsterStartCoordinates(ArrayList<String> monsterStartCoordinates) {
        Monster.monsterStartCoordinates = monsterStartCoordinates;
    }
    public int getMonsterX() {
        return monsterX;
    }
    public int getMonsterY() {
        return monsterY;
    }
    public static ArrayList<String> getMonsterAndHumanMovesLog() {
        return monsterAndHumanMovesLog;
    }
//!!!ENDING OF SETTERS AND GETTERS!!!
    public void wantsToMoveOnX(int humanX, int humanY){
        String stringForLog;
        if(this.monsterIsInHole == 0) {
            //This is an arrayList to store all the valid moves.
            ArrayList<ArrayList<Integer>> validMoves = new ArrayList<ArrayList<Integer>>();
            //This is an arrayList to store all the possible moves.
            ArrayList<ArrayList<Integer>> possibleMoves = new ArrayList<ArrayList<Integer>>();
            //With this formula we are figuring out the absolute distance
            //between the human and the monster in its current position.
            int currentDistance = Math.abs(humanX - this.monsterX) + Math.abs(humanY - this.monsterY);
            //Now we need to figure out the coordinates of all the
            //neighboring tiles and decide if they are valid tiles.
            int x;
            int y;
            //Here we figure out the moves on the x-axis first, because
            //these have priority. If we can't find any legitimate moves,
            //we move on to the y-axis moves.
            //Left.
            y = this.monsterY;
            x = this.monsterX - 1;
            if (x > 0) {
                if (currentDistance > (Math.abs(humanX - x) + Math.abs(humanY - y))) {
                    ArrayList<Integer> validBoardersMove = new ArrayList<Integer>();
                    validBoardersMove.add(x);
                    validBoardersMove.add(y);
                    possibleMoves.add(validBoardersMove);
                }
            }
            //Right.
            y = this.monsterY;
            x = this.monsterX + 1;
            if (x <= BoardRoom.getXAxis()) {
                if (currentDistance > (Math.abs(humanX - x) + Math.abs(humanY - y))) {
                    ArrayList<Integer> validBoardersMove = new ArrayList<Integer>();
                    validBoardersMove.add(x);
                    validBoardersMove.add(y);
                    possibleMoves.add(validBoardersMove);
                }
            }
            //Now to figure out if the move on the x-axis is invalid due to walls.
            //We are using the terrain method here.
            if (possibleMoves.isEmpty() == false) {
                if (Terrain.monsterMoveIsFreeOfTerrain(this.monsterX, this.monsterY,
                        possibleMoves.get(0).get(0), possibleMoves.get(0).get(1))) {
                    validMoves.add(possibleMoves.get(0));
                }
            }
            //Now we need to check if there are any moves in the validMoves
            //arraylist. If not, we need to try and move on the y-axis.
            if (validMoves.isEmpty() == true) {
                //Down.
                y = this.monsterY - 1;
                x = this.monsterX;
                if (y > 0) {
                    if (currentDistance > (Math.abs(humanX - x) + Math.abs(humanY - y))) {
                        ArrayList<Integer> validBoardersMove = new ArrayList<Integer>();
                        validBoardersMove.add(x);
                        validBoardersMove.add(y);
                        possibleMoves.add(validBoardersMove);
                    }
                }
                //Up.
                y = this.monsterY + 1;
                x = this.monsterX;
                if (y <= BoardRoom.getYAxis()) {
                    if (currentDistance > (Math.abs(humanX - x) + Math.abs(humanY - y))) {
                        ArrayList<Integer> validBoardersMove = new ArrayList<Integer>();
                        validBoardersMove.add(x);
                        validBoardersMove.add(y);
                        possibleMoves.add(validBoardersMove);
                    }
                }
                //Now to figure out if the move on the y-axis is invalid due to walls. We are using the terrain method here.
                if (possibleMoves.isEmpty() == false) {
                    if (Terrain.monsterMoveIsFreeOfTerrain(this.monsterX, this.monsterY,
                            possibleMoves.get(0).get(0), possibleMoves.get(0).get(1))) {
                        validMoves.add(possibleMoves.get(0));
                    }
                }
            }
            //If the validMoves arraylist is STILL empty, it
            //means that the monster can't move.
            //Now we need to record our moves in the designated arraylist.
            if (validMoves.isEmpty() == false) {
                this.setMonsterX(validMoves.get(0).get(0));
                this.setMonsterY(validMoves.get(0).get(1));
                stringForLog = "The monster moves to: " + this.getMonsterX() + "," + this.getMonsterY();
                monsterAndHumanMovesLog.add(stringForLog);

                if(this.monsterFellInHole() == true){
                    this.monsterIsInHole = 5;
                    String stringForLog2 = "The monster falls into a hole with move 1 of this turn, no move on the y-axis this turn.";
                    monsterAndHumanMovesLog.add(stringForLog2);
                }

            }else{
                stringForLog = "The monster has no move that will take it closer to the human.";
                monsterAndHumanMovesLog.add(stringForLog);

            }
        }
        else{
            this.monsterIsInHole -=1;
            stringForLog = "The monster is in a hole, no move this turn.";
            monsterAndHumanMovesLog.add(stringForLog);
        }
    }
    public void wantsToMoveOnY(int humanX, int humanY){
        String stringForLog;
        if(this.monsterIsInHole == 0) {
            //This is an arrayList to store all the valid moves.
            ArrayList<ArrayList<Integer>> validMoves = new ArrayList<ArrayList<Integer>>();
            //This is an arrayList to store all the possible moves.
            ArrayList<ArrayList<Integer>> possibleMoves = new ArrayList<ArrayList<Integer>>();
            //With this formula we are figuring out the absolute distance
            //between the human and the monster in its current position.
            int currentDistance = Math.abs(humanX - this.monsterX) + Math.abs(humanY - this.monsterY);
            //Now we need to figure out the coordinates of all the
            //neighboring tiles and decide if they are valid tiles.
            int x;
            int y;
            //Here we figure out the moves on the x-axis first, because
            //these have priority. If we can't find any legitimate moves,
            //we move on to the x-axis moves.
            //Down.
            y = this.monsterY - 1;
            x = this.monsterX;
            if (y > 0) {
                if (currentDistance > (Math.abs(humanX - x) + Math.abs(humanY - y))) {
                    ArrayList<Integer> validBoardersMove = new ArrayList<Integer>();
                    validBoardersMove.add(x);
                    validBoardersMove.add(y);
                    possibleMoves.add(validBoardersMove);
                }
            }
            //Up.
            y = this.monsterY + 1;
            x = this.monsterX;
            if (y <= BoardRoom.getYAxis()) {
                if (currentDistance > (Math.abs(humanX - x) + Math.abs(humanY - y))) {
                    ArrayList<Integer> validBoardersMove = new ArrayList<Integer>();
                    validBoardersMove.add(x);
                    validBoardersMove.add(y);
                    possibleMoves.add(validBoardersMove);
                }
            }
            //Now to figure out if the move on the x-axis is invalid due to walls.
            //We are using the terrain method here.
            if (possibleMoves.isEmpty() == false) {
                if (Terrain.monsterMoveIsFreeOfTerrain(this.monsterX, this.monsterY, possibleMoves.get(0).get(0), possibleMoves.get(0).get(1))) {
                    validMoves.add(possibleMoves.get(0));
                }
            }
            //Now we need to check if there are any moves in the validMoves
            //arraylist. If not, we need to try and move on the x-axis.
            if (validMoves.isEmpty() == true) {
                //Left.
                y = this.monsterY;
                x = this.monsterX - 1;
                if (x > 0) {
                    if (currentDistance > (Math.abs(humanX - x) + Math.abs(humanY - y))) {
                        ArrayList<Integer> validBoardersMove = new ArrayList<Integer>();
                        validBoardersMove.add(x);
                        validBoardersMove.add(y);
                        possibleMoves.add(validBoardersMove);
                    }
                }
                //Right.
                y = this.monsterY;
                x = this.monsterX + 1;
                if (x <= BoardRoom.getXAxis()) {
                    if (currentDistance > (Math.abs(humanX - x) + Math.abs(humanY - y))) {
                        ArrayList<Integer> validBoardersMove = new ArrayList<Integer>();
                        validBoardersMove.add(x);
                        validBoardersMove.add(y);
                        possibleMoves.add(validBoardersMove);
                    }
                }
                //Now to figure out if the move on the y-axis is invalid due to walls.
                //We are using the terrain method here.
                if (possibleMoves.isEmpty() == false) {
                    if (Terrain.monsterMoveIsFreeOfTerrain(this.monsterX, this.monsterY, possibleMoves.get(0).get(0), possibleMoves.get(0).get(1))) {
                        validMoves.add(possibleMoves.get(0));
                    }
                }
            }
            //If the validMoves arraylist is STILL empty, it
            //means that the monster can't move.
            //Now we need to record our moves in the designated arraylist.
            if (validMoves.isEmpty() == false) {
                this.setMonsterX(validMoves.get(0).get(0));
                this.setMonsterY(validMoves.get(0).get(1));
                stringForLog = "The monster moved to: " + this.getMonsterX() + "," + this.getMonsterY();
                monsterAndHumanMovesLog.add(stringForLog);

                if(this.monsterFellInHole() == true){
                    this.monsterIsInHole = 4;
                    String stringForLog2 = "The monster falls into a hole with move 2 of this turn.";
                    monsterAndHumanMovesLog.add(stringForLog2);
                }
            }
        }
        else{
            this.monsterIsInHole -=1;
            stringForLog = "The monster is in a hole, no move this turn.";
            monsterAndHumanMovesLog.add(stringForLog);
        }
    }
    //And finally, we are going to combine these 3 methods to create the
    //actual sequence that happens when the monster wants to move.
    public void monsterMoves(Human human){
        String stringForLog;
        int humanX = human.getHumanX();
        int humanY = human.getHumanY();
        monsterAndHumanMovesLog.add("Human moves to: " + humanX + "," + humanY);
        if( human.humanIsOnExit() == true){
            stringForLog = "The human has reached the exit!!!";
            monsterAndHumanMovesLog.add(stringForLog);
            EscapeAttempt.setHumanEscaped(true);
        } else{
            if(this.humanIsEaten(humanX,humanY) == false){
                this.wantsToMoveOnX(humanX,humanY);
                if(this.humanIsEaten(humanX,humanY) == false){
                    this.wantsToMoveOnY(humanX,humanY);
                    if(this.humanIsEaten(humanX,humanY) == true){
                        stringForLog = "The monster eats the human with its second move!";
                        monsterAndHumanMovesLog.add(stringForLog);
                        EscapeAttempt.setHumanIsEaten(true);
                    }
                }else{
                    stringForLog = "The monster eats the human with its first move!";
                    monsterAndHumanMovesLog.add(stringForLog);
                    EscapeAttempt.setHumanIsEaten(true);
                }
            }else{
                stringForLog = "The human walks into the monster and gets eaten by it!";
                monsterAndHumanMovesLog.add(stringForLog);
                EscapeAttempt.setHumanIsEaten(true);
            }
        }
    }
}
