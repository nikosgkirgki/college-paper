import java.util.ArrayList;

public class Terrain {
    //We begin by creating two lists to keep track of
    //all the holes and walls in the boardroom.
    private static ArrayList<Tile> HoleTiles = new ArrayList<Tile>();
    private static ArrayList<ArrayList<Integer>> coordinatesOfWalls = new ArrayList<ArrayList<Integer>>();

    //With this here method we are going to fill the coordinatesOfWalls
    //arraylist with the coordinates of all the walls in our BoardRoom.
    public static void generateWalls(String[] wallsAsString){
        //The int (i) is increased by 4, since once we get
        //the first 4 numbers in the array, we need
        //to move to the next 4.
        for(int i = 0; i < wallsAsString.length; i+=4){
            ArrayList<Integer> wall = new ArrayList<Integer>();
            //With this here for loop, we get the 4 numbers
            //in the String array, starting with the one in the
            //(i) position, convert them from String to int,
            //inject the ints into an arraylist...
            for(int set = i; set < i + 4; set++){
                int a = Integer.parseInt(wallsAsString[set]);
                wall.add(a);
            }
            //...and lastly,inject the integer-arraylist
            // to the arraylist "coordinatesOfWalls".
            coordinatesOfWalls.add(wall);
        }
    }
    //This is the method called, whenever we attempt to
    //make a move. This method will check if the human's
    //move is valid, based on where the holes and walls are.
    public static boolean humanMoveIsFreeOfTerrain(int fromX, int fromY, int toX, int toY){
        //First we create the boolean value that will confirm
        //whether the move is valid or not.
        boolean moveIsValid = true;
        //First, let's check the holes. If a hole's x and y
        //are similar to the x and y we want to go to,
        //then the move is invalid.
        for(int i = 0; i < HoleTiles.size(); i++){
            if(HoleTiles.get(i).getX() == toX && HoleTiles.get(i).getY() == toY){
                moveIsValid = false;
                break;
            }
        }
        if(moveIsValid == true) {
            //Now to check if there are walls between the two tiles.
            //In both cases, we will use 2 for loops. We must first check
            //if the 0-1 array spaces match the (from) coordinates, and then,
            //if not, then check if the 2-3 array spaces match.
            //If we get a match, we need to then check if we are moving
            //into a wall by following the exact same procedure.
            for (int i = 0; i < coordinatesOfWalls.size(); i++) {
                if (coordinatesOfWalls.get(i).get(0) == fromX && coordinatesOfWalls.get(i).get(1) == fromY) {
                    if (coordinatesOfWalls.get(i).get(2) == toX && coordinatesOfWalls.get(i).get(3) == toY) {
                        moveIsValid = false;
                    }
                }
                //Now we are going to do the same as we did above, but
                //with the values having switched places.
                if (coordinatesOfWalls.get(i).get(2) == fromX && coordinatesOfWalls.get(i).get(3) == fromY) {
                    if (coordinatesOfWalls.get(i).get(0) == toX && coordinatesOfWalls.get(i).get(1) == toY) {
                        moveIsValid = false;
                    }
                }
            }
        }
        return moveIsValid;
    }
    //This method is used by the BoardRoom class, to
//give us all the hole tiles, which we put into
//the HoleTiles arraylist.
    public static boolean monsterMoveIsFreeOfTerrain(int fromX, int fromY, int toX, int toY){
        //First we create the boolean value that will confirm
        //whether the move is valid or not.
        boolean moveIsValid = true;
        //Now to check if there are walls between the two tiles.
        //In both cases, we will use 2 for loops. We must first check
        //if the 0-1 array spaces match the (from) coordinates, and then,
        //if not, then check if the 2-3 array spaces match.
        //If we get a match, we need to then check if we are moving
        //into a wall by following the exact same procedure.
        for(int i = 0; i < coordinatesOfWalls.size(); i++){
            if(coordinatesOfWalls.get(i).get(0) == fromX && coordinatesOfWalls.get(i).get(1) == fromY){
                if(coordinatesOfWalls.get(i).get(2) == toX && coordinatesOfWalls.get(i).get(3) == toY){
                    moveIsValid = false;
                }
            }
            //Now we are going to do the same as we did above, but
            //with the values having switched places.
            if(coordinatesOfWalls.get(i).get(2) == fromX && coordinatesOfWalls.get(i).get(3) == fromY){
                if(coordinatesOfWalls.get(i).get(0) == toX && coordinatesOfWalls.get(i).get(1) == toY){
                    moveIsValid = false;
                }
            }
        }
        return moveIsValid;
    }
//BEGINNING OF SETTERS AND GETTERS!!!
    public static void setHoles(ArrayList<Tile> holes){
        HoleTiles = holes;
    }
    public static ArrayList<Tile> getHoles() {
        return HoleTiles;
    }
//ENDING OF SETTERS AND GETTERS!!!


}
