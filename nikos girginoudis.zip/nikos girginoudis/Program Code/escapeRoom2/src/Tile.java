public class Tile {
    private int x;
    private int y;
    private String tileType; // "normal" / "hole" / "exit"

    public Tile (int x, int y, String tileType){
        this.x = x;
        this.y = y;
        this.tileType = tileType;
    }
//BEGINNING OF GETTERS AND SETTERS!!!
    public int getX() {
        return x;
    }
    public int getY() {
        return y;
    }
    public void setX(int x) {
        this.x = x;
    }
    public void setY(int y) {
        this.y = y;
    }
    public String getTileType() {return tileType;}
    public void setTileType(String tileType) {
        this.tileType = tileType;
    }
//ENDING OF GETTERS AND SETTERS!!!
}
